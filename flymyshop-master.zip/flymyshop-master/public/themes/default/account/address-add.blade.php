@extends('layouts.lmain')
@section('content')



    <a class="btn btn-default" href="{{$url}}">Update address</a>

@stop