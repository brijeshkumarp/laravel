@extends('layouts.lmain')
@section('content')
    Contact Page
@stop