<p>
    Name: {{$name}}
</p>

<p>
    {{$email}}
</p>

<p>
    {{$message}}
</p>