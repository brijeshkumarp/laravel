
@extends('layouts.main')
@section('content')



    <h1> {{$page->title}} </h1>


    <article>
        {{$page->contact}}
    </article>



@stop