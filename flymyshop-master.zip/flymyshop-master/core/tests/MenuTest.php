<?php

//TODO: add test when functions are added and check menus can be generated

//class MenuTest extends TestCase
//{
//
//}
