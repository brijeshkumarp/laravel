<?php

//Add test for native and third-party support

//class NewsletterTest extends TestCase
//{
//    public function testExample()
//    {
//        $this->assertTrue(true);
//    }
//}
