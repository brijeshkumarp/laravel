<?php

return [
    'account' => 'Account Centre',
];
