<?php

return [
    'welcome' => 'Welcome to ',
];
