<div style="color: red" class="form-errors">
{{ HTML::ul($errors->all()) }}
</div>