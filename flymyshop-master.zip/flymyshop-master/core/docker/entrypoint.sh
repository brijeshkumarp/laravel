#!/bin/sh
cd /var/www/html/core
php artisan queue:listen