<?php

return [
    'shopName' =>  str_replace('_', ' ', env('SHOP_NAME')),
];
