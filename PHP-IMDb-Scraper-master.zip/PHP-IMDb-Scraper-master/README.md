PHP-IMDb-Scraper
================

Demo: http://lab.abhinayrathore.com/imdb/
