laravel-linkedin-login
======================

A small Laravel application with Linkedin login to pull user's data from LinkedIn.
The detailed tutorial on how it was created is located on my blog: 
http://wp.me/p1Zx0U-yp

The demo is hosted on Pagodabox here: 
http://laravel-linkedin-login.gopagoda.com
