<?php
// app/config/facebook.php

// Facebook app Config 
return array(
    'appId' => getenv('fb_id'),
    'secret' => getenv('fb_secret')
);