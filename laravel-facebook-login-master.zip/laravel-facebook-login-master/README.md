laravel-facebook-login
======================

A complete application with Facebook login and a tutorial
